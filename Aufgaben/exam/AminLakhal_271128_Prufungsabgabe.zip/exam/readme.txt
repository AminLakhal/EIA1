deutsch spanisch und deutsch ukrainisch funktionieren

bei start aus dem Ordner ohne den vscode server funktionierte die seite erst nach refresh bei mir 

